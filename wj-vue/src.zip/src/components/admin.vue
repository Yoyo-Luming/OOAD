<template>

</template>

<script>
export default {
  name: 'admin'
}
</script>

<style scoped>

</style>
