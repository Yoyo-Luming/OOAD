<template>
  <div>
    Hello World!
  </div>
</template>

<script>
export default {
  name: 'AppIndex'
}
</script>

<style scoped>

</style>
